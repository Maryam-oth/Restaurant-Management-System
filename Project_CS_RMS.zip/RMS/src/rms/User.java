/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rms;

/**
 *
 * @author hamsa
 */
public class User 
{
    
    
  

    protected String UserName;
    public String PhoneNum;
    public String Email;



    public User(){}

    public String getPhoneNum() { return PhoneNum; }

  
    public String getEmail() { return Email; }

  
    public String getAdminUserName() {
        return UserName;
    }


    
    
}

